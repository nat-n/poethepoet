from __future__ import annotations

from cleo.exceptions import CleoSimpleException


class PoetrySimpleConsoleException(CleoSimpleException):  # type: ignore[misc]
    pass
