from __future__ import annotations

import logging


POETRY_FILTER = logging.Filter(name="poetry")
