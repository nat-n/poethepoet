
from .main import chars, char_names, get_output_string, \
beavis, cheese, daemon, cow, \
dragon, ghostbusters, kitty, meow, milk, pig, stegosaurus, \
stimpy, trex, turkey, turtle, tux
